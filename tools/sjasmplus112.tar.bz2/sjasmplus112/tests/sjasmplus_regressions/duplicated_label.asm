lab     nop
lab     ret
