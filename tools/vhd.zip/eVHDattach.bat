@echo off
if exist VHDattach.txt (
	@echo on
	echo VHDattach.txt exist
	@echo off
) else (
	@echo on
	echo create VHDattach.txt
	@echo off
	echo select vdisk file="%cd%\sd.vhd" > VHDattach.txt
	echo attach vdisk >> VHDattach.txt
	rem echo select vdisk file="%cd%\sd.vhd" >> VHDattach.txt
	rem echo select part 1 >> VHDattach.txt
	rem echo assign letter=K >> VHDattach.txt
)
if exist sd.vhd (
	@echo on
	echo sd.vhd attach
	diskpart /s VHDattach.txt
	@echo off
) else (
	@echo on
	echo create VHDcreate.txt
	@echo off
	echo create vdisk file="%cd%\sd.vhd" MAXIMUM=300 TYPE=FIXED > VHDcreate.txt
	echo select vdisk file="%cd%\sd.vhd" >> VHDcreate.txt
	echo attach vdisk >> VHDcreate.txt
	echo create part primary  >> VHDcreate.txt
	echo select part 1 >> VHDcreate.txt
	echo format label="ZX" quick fs=FAT32 >> VHDcreate.txt
	echo assign >> VHDcreate.txt
	@echo on
	diskpart /s VHDcreate.txt
	del VHDcreate.txt
	@echo off
)
@echo on
pause