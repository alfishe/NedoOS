@echo off
if exist VHDdetach.txt (
	@echo on
	echo VHDdetach.txt exist
	@echo off
) else (
	@echo on
	echo create VHDdetach.txt
	@echo off
	echo select vdisk file="%cd%\sd.vhd" > VHDdetach.txt
	echo detach vdisk >> VHDdetach.txt
)
@echo on
diskpart /s VHDdetach.txt
pause